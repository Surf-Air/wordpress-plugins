<?php
  define('PARDOT_WP_LOAD', "{$_SERVER['DOCUMENT_ROOT']}/wp/wp-load.php");
